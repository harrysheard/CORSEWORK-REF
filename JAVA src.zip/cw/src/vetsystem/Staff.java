package vetsystem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class Staff implements Serializable {
    private static final long serialVersionUID = 1L;

    private String staffNo;
    private String name;
    private ContactDetails contactDetails;
    private Surgery defaultSurgery;
    private List<Booking> bookings;

    public Staff(String staffNo, String name, ContactDetails contactDetails, Surgery defaultSurgery) {
        if (staffNo == null || staffNo.length() != 5 || !staffNo.matches("[0-9]+")) {
            throw new IllegalArgumentException("Staff number must be exactly 5 digits!");
        }
        this.staffNo = staffNo;
        this.name = name;
        this.contactDetails = contactDetails;
        this.defaultSurgery = defaultSurgery;
        this.bookings = new ArrayList<Booking>();
    }

    public String getStaffNo() { 
        return staffNo; 
    }
    
    public String getName() { 
        return name; 
    }
    
    public ContactDetails getContactDetails() { 
        return contactDetails; 
    }
    
    public Surgery getDefaultSurgery() { 
        return defaultSurgery; 
    }
    
    public List<Booking> getBookings() { 
        return bookings; 
    }

    public void addBooking(Booking b) { 
        this.bookings.add(b); 
    }
    
    public void removeBooking(Booking b) { 
        this.bookings.remove(b); 
    }

    public abstract Booking getNextBooking();
    
    public List<Booking> getAllBookings() { 
        return this.bookings; 
    }
}