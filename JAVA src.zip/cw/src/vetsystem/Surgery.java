package vetsystem;

import java.io.Serializable;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Surgery implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String postCode;
    private LocalTime openingTime;
    private LocalTime closingTime;
    private String weeklyTrainingSlot;

    private List<Staff> staffList = new ArrayList<Staff>();
    private List<Pet> petList = new ArrayList<Pet>();
    private List<Booking> bookingList = new ArrayList<Booking>();

    public Surgery(String name, String postCode, LocalTime openingTime, LocalTime closingTime, String weeklyTrainingSlot) {
        this.name = name;
        this.postCode = postCode;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.weeklyTrainingSlot = weeklyTrainingSlot;
    }

    public String getName() { 
        return name; 
    }
    
    public List<Staff> getStaffList() { 
        return staffList; 
    }
    
    public List<Pet> getPetList() { 
        return petList; 
    }
    
    public List<Booking> getBookingList() { 
        return bookingList; 
    }

    public void registerStaff(Staff s) { 
        staffList.add(s); 
    }
    
    public void removeStaff(Staff s) { 
        staffList.remove(s); 
    }
    
    public Staff searchStaff(String staffNo) {
        for (int i = 0; i < staffList.size(); i++) {
            Staff s = staffList.get(i);
            if (s.getStaffNo().equals(staffNo)) {
                return s;
            }
        }
        return null;
    }

    public void registerPet(Pet p) { 
        petList.add(p); 
    }
    
    public void removePet(Pet p) { 
        petList.remove(p); 
    }
    
    public Pet searchPet(String petRef) {
        for (int i = 0; i < petList.size(); i++) {
            Pet p = petList.get(i);
            if (p.getPetRef().equalsIgnoreCase(petRef)) {
                return p;
            }
        }
        return null;
    }

    public void makeBooking(Booking b) { 
        bookingList.add(b); 
        b.getPet().addBooking(b);
        for (int i = 0; i < b.getAssignedStaff().size(); i++) {
            b.getAssignedStaff().get(i).addBooking(b);
        }
    }
    
    public void cancelBooking(Booking b) { 
        bookingList.remove(b); 
        b.getPet().removeBooking(b);
        for (int i = 0; i < b.getAssignedStaff().size(); i++) {
            b.getAssignedStaff().get(i).removeBooking(b);
        }
    }

    public boolean checkStaffAvailability(Staff s, LocalDateTime start, LocalDateTime end) {
        for (int i = 0; i < bookingList.size(); i++) {
            Booking b = bookingList.get(i);
            if (b.getAssignedStaff().contains(s)) {
                if (start.isBefore(b.getEndTime()) && end.isAfter(b.getStartTime())) {
                    return false; 
                }
            }
        }
        return true; 
    }
}