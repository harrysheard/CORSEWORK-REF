package vetsystem;

import java.io.*;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class main {
    private static final String FILE_NAME = "surgery_data.ser";
    private static List<Surgery> surgeries = new ArrayList<Surgery>();
    private static Scanner scan = new Scanner(System.in);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static void main(String[] args) {
        loadFromFile();

        if (surgeries.isEmpty()) {
            surgeries.add(new Surgery("Byrom Veterinary Clinic", "L3 3AF", LocalTime.of(9, 0), LocalTime.of(17, 0), "Wednesday Afternoon"));
        }

        Surgery currentSurgery = surgeries.get(0);
        boolean loopRunning = true;

        while (loopRunning) {
            System.out.println("\n===============================================");
            System.out.println("VET SURGERY SYSTEM MAIN MENU - " + currentSurgery.getName().toUpperCase());
            System.out.println("===============================================");
            System.out.println("1) Register New Staff Member");
            System.out.println("2) Delete / Remove Staff");
            System.out.println("3) Search for Staff Info");
            System.out.println("4) Check Staff Member Availability");
            System.out.println("5) Register New Pet Record");
            System.out.println("6) Delete / Remove Pet");
            System.out.println("7) Search for Pet Info");
            System.out.println("8) Create New Appointment Booking");
            System.out.println("9) Cancel Appointment Booking");
            System.out.println("10) View List of All Current Bookings");
            System.out.println("11) Save State Data and Exit");
            System.out.print("Please enter selection (1-11): ");

            String inputLine = scan.nextLine().trim();
            int menuSelection = -1;
            
            try {
                menuSelection = Integer.parseInt(inputLine);
            } catch (NumberFormatException e) {
                System.out.println("Error: Must input a valid number.");
                continue;
            }

            if (menuSelection == 1) {
                runRegisterStaff(currentSurgery);
            } else if (menuSelection == 2) {
                runRemoveStaff(currentSurgery);
            } else if (menuSelection == 3) {
                runSearchStaff(currentSurgery);
            } else if (menuSelection == 4) {
                runCheckStaffAvailable(currentSurgery);
            } else if (menuSelection == 5) {
                runRegisterPet(currentSurgery);
            } else if (menuSelection == 6) {
                runRemovePet(currentSurgery);
            } else if (menuSelection == 7) {
                runSearchPet(currentSurgery);
            } else if (menuSelection == 8) {
                runMakeBooking(currentSurgery);
            } else if (menuSelection == 9) {
                runCancelBooking(currentSurgery);
            } else if (menuSelection == 10) {
                runPrintAllBookings(currentSurgery);
            } else if (menuSelection == 11) {
                saveToFile();
                loopRunning = false;
                System.out.println("Data saved successfully. Exiting application.");
            } else {
                System.out.println("Invalid selection option. Try again.");
            }
        }
    }

    private static void runRegisterStaff(Surgery surg) {
        System.out.print("Enter 5-digit Staff ID Number: ");
        String id = scan.nextLine().trim();
        System.out.print("Enter Full Name: ");
        String name = scan.nextLine().trim();
        System.out.print("Enter Contact Email Address: ");
        String email = scan.nextLine().trim();
        System.out.print("Enter Contact Phone Number: ");
        String phone = scan.nextLine().trim();
        System.out.print("Type -> Press 1 for Surgeon, Press 2 for Nurse: ");
        String staffType = scan.nextLine().trim();

        try {
            ContactDetails info = new ContactDetails(email, phone);
            if (staffType.equals("1")) {
                surg.registerStaff(new Surgeon(id, name, info, surg));
            } else {
                surg.registerStaff(new Nurse(id, name, info, surg));
            }
            System.out.println("Staff successfully saved to roster!");
        } catch (Exception e) {
            System.out.println("Failed to create staff record: " + e.getMessage());
        }
    }

    private static void runRemoveStaff(Surgery surg) {
        System.out.print("Enter the Staff ID to remove: ");
        String id = scan.nextLine().trim();
        Staff target = surg.searchStaff(id);
        if (target != null) {
            surg.removeStaff(target);
            System.out.println("Staff entry dropped from roster system.");
        } else {
            System.out.println("No matching staff found with that number.");
        }
    }

    private static void runSearchStaff(Surgery surg) {
        System.out.print("Enter Staff ID Number to look up: ");
        String id = scan.nextLine().trim();
        Staff found = surg.searchStaff(id);
        if (found != null) {
            System.out.println("MATCH FOUND: " + found.getName() + " Roles: [" + found.getClass().getSimpleName() + "] Contacts: " + found.getContactDetails().toString());
        } else {
            System.out.println("No staff member matches that criteria.");
        }
    }

    private static void runCheckStaffAvailable(Surgery surg) {
        System.out.print("Enter Staff ID Number: ");
        String id = scan.nextLine().trim();
        Staff st = surg.searchStaff(id);
        if (st == null) {
            System.out.println("Staff member not found inside system.");
            return;
        }
        try {
            System.out.print("Enter Check Window Start Time (format: yyyy-MM-dd HH:mm): ");
            LocalDateTime sTime = LocalDateTime.parse(scan.nextLine().trim(), DATE_FORMAT);
            System.out.print("Enter Check Window End Time (format: yyyy-MM-dd HH:mm): ");
            LocalDateTime eTime = LocalDateTime.parse(scan.nextLine().trim(), DATE_FORMAT);
            
            boolean clear = surg.checkStaffAvailability(st, sTime, eTime);
            if (clear) {
                System.out.println("Result: Staff member is AVAILABLE for booking.");
            } else {
                System.out.println("Result: Staff member is CLASHED / OCCUPIED during this period.");
            }
        } catch (Exception e) {
            System.out.println("Input execution error. Check your date format layout.");
        }
    }

    private static void runRegisterPet(Surgery surg) {
        System.out.print("Enter 5-digit Hex Reference String: ");
        String ref = scan.nextLine().trim();
        System.out.print("Enter Pet Patient Name: ");
        String name = scan.nextLine().trim();
        System.out.print("Species -> Press 1 for Cat, Press 2 for Fish: ");
        String selectedType = scan.nextLine().trim();

        try {
            if (selectedType.equals("1")) {
                System.out.print("Enter Breeding Profile (Moggie or Pedigree): ");
                String breedInfo = scan.nextLine().trim();
                surg.registerPet(new Cat(ref, name, surg, breedInfo));
            } else {
                System.out.print("Enter Aquatic Tank Setup Type (Fresh or Salt): ");
                String waterInfo = scan.nextLine().trim();
                surg.registerPet(new Fish(ref, name, surg, waterInfo));
            }
            System.out.println("Pet patient registered successfully.");
        } catch (Exception e) {
            System.out.println("Failed creating profile structure: " + e.getMessage());
        }
    }

    private static void runRemovePet(Surgery surg) {
        System.out.print("Enter Pet Reference code to delete: ");
        String ref = scan.nextLine().trim();
        Pet target = surg.searchPet(ref);
        if (target != null) {
            surg.removePet(target);
            System.out.println("Pet record deleted safely.");
        } else {
            System.out.println("No pet matches that hex identifier reference.");
        }
    }

    private static void runSearchPet(Surgery surg) {
        System.out.print("Enter Pet Hex Ref: ");
        String ref = scan.nextLine().trim();
        Pet found = surg.searchPet(ref);
        if (found != null) {
            System.out.println("MATCH FOUND: Name: " + found.getName() + " Species Class: (" + found.getSpeciesName() + ")");
        } else {
            System.out.println("No pet patient matching that search entry found.");
        }
    }

    private static void runMakeBooking(Surgery surg) {
        System.out.print("Enter target Pet Reference ID: ");
        String pRef = scan.nextLine().trim();
        Pet petObj = surg.searchPet(pRef);
        if (petObj == null) {
            System.out.println("Error: Pet must be in the database register first.");
            return;
        }

        System.out.print("Enter assigned Staff Member ID: ");
        String sRef = scan.nextLine().trim();
        Staff staffObj = surg.searchStaff(sRef);
        if (staffObj == null) {
            System.out.println("Error: Staff ID could not be loaded.");
            return;
        }

        try {
            System.out.print("Enter Start Date Time (yyyy-MM-dd HH:mm): ");
            LocalDateTime start = LocalDateTime.parse(scan.nextLine().trim(), DATE_FORMAT);
            System.out.print("Enter End Date Time (yyyy-MM-dd HH:mm): ");
            LocalDateTime end = LocalDateTime.parse(scan.nextLine().trim(), DATE_FORMAT);

            if (!surg.checkStaffAvailability(staffObj, start, end)) {
                System.out.println("Declined: Cannot finalize due to scheduling time conflict.");
                return;
            }

            Booking newAppt = new Booking(petObj, start, end);
            newAppt.addStaff(staffObj);
            surg.makeBooking(newAppt);
            System.out.println("Appointment setup complete. Track UUID: " + newAppt.getBookingRef());
        } catch (Exception e) {
            System.out.println("Process aborted: Formatting or validation issues -> " + e.getMessage());
        }
    }

    private static void runCancelBooking(Surgery surg) {
        System.out.print("Enter Booking UUID string context to drop: ");
        String userUUID = scan.nextLine().trim();
        try {
            java.util.UUID matchTarget = java.util.UUID.fromString(userUUID);
            Booking finalMatch = null;
            
            for (int i = 0; i < surg.getBookingList().size(); i++) {
                Booking check = surg.getBookingList().get(i);
                if (check.getBookingRef().equals(matchTarget)) {
                    finalMatch = check;
                    break;
                }
            }

            if (finalMatch != null) {
                surg.cancelBooking(finalMatch);
                System.out.println("Appointment has been dropped from surgery books.");
            } else {
                System.out.println("No record matched that specific UUID string.");
            }
        } catch (Exception e) {
            System.out.println("Malformed UUID string value submitted.");
        }
    }

    private static void runPrintAllBookings(Surgery surg) {
        List<Booking> snapshot = surg.getBookingList();
        if (snapshot.isEmpty()) {
            System.out.println("Roster notice: There are currently no bookings configured.");
            return;
        }
        System.out.println("--- CURRENT ACTIVE APPOINTMENTS ROSTER ---");
        for (int i = 0; i < snapshot.size(); i++) {
            Booking b = snapshot.get(i);
            System.out.println("[" + (i+1) + "] ID: " + b.getBookingRef() + " | Pet: " + b.getPet().getName() + " | Period: " + b.getStartTime().format(DATE_FORMAT) + " to " + b.getEndTime().format(DATE_FORMAT));
        }
    }

    private static void saveToFile() {
        try {
            ObjectOutputStream oOut = new ObjectOutputStream(new FileOutputStream(FILE_NAME));
            oOut.writeObject(surgeries);
            oOut.close();
        } catch (IOException e) {
            System.out.println("Error saving local file: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadFromFile() {
        File dataStore = new File(FILE_NAME);
        if (!dataStore.exists()) {
            return;
        }
        try {
            ObjectInputStream oIn = new ObjectInputStream(new FileInputStream(dataStore));
            surgeries = (List<Surgery>) oIn.readObject();
            oIn.close();
        } catch (Exception e) {
            System.out.println("Notice: Generative memory clear initialized.");
        }
    }
}