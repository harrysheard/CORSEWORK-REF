package vetsystem;

import java.io.Serializable;

public class ContactDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String email;
    private String phoneNumber;

    public ContactDetails(String email, String phoneNumber) {
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() { 
        return email; 
    }
    
    public String getPhoneNumber() { 
        return phoneNumber; 
    }

    @Override
    public String toString() {
        return "Email: " + email + ", Phone: " + phoneNumber;
    }
}