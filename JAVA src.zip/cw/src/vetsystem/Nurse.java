package vetsystem;

public class Nurse extends Staff {
    private static final long serialVersionUID = 1L;

    public Nurse(String staffNo, String name, ContactDetails contactDetails, Surgery defaultSurgery) {
        super(staffNo, name, contactDetails, defaultSurgery);
    }

    @Override
    public Booking getNextBooking() {
        if (getAllBookings().isEmpty()) {
            return null;
        }
        return getAllBookings().get(0);
    }
}