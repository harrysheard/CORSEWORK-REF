package vetsystem;

import java.util.ArrayList;
import java.util.List;

public class Surgeon extends Staff {
    private static final long serialVersionUID = 1L;
    
    private List<Surgery> consultingSurgeries;

    public Surgeon(String staffNo, String name, ContactDetails contactDetails, Surgery defaultSurgery) {
        super(staffNo, name, contactDetails, defaultSurgery);
        this.consultingSurgeries = new ArrayList<Surgery>();
    }

    public void addConsultingSurgery(Surgery s) {
        if (!consultingSurgeries.contains(s)) {
            consultingSurgeries.add(s);
        }
    }

    public List<Surgery> getConsultingSurgeries() { 
        return consultingSurgeries; 
    }

    @Override
    public Booking getNextBooking() {
        if (getAllBookings().isEmpty()) {
            return null;
        }
        return getAllBookings().get(0); 
    }
}