package vetsystem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class Pet implements Serializable {
    private static final long serialVersionUID = 1L;

    private String petRef;
    private String name;
    private String speciesName;
    private Date regDate;
    private List<Surgery> registeredSurgeries;
    private List<Booking> bookings;

    public Pet(String petRef, String name, String speciesName, Surgery initialSurgery) {
        if (petRef == null || !petRef.matches("^[0-9A-Fa-f]{5}$")) {
            throw new IllegalArgumentException("Pet reference code must be a 5-digit hex value.");
        }
        this.petRef = petRef.toUpperCase();
        this.name = name;
        this.speciesName = speciesName;
        this.regDate = new Date();
        this.registeredSurgeries = new ArrayList<Surgery>();
        this.bookings = new ArrayList<Booking>();
        
        if (initialSurgery != null) {
            this.registeredSurgeries.add(initialSurgery);
        }
    }

    public String getPetRef() { 
        return petRef; 
    }
    
    public String getName() { 
        return name; 
    }
    
    public String getSpeciesName() { 
        return speciesName; 
    }
    
    public List<Booking> getBookings() { 
        return bookings; 
    }
    
    public void addBooking(Booking b) { 
        this.bookings.add(b); 
    }
    
    public void removeBooking(Booking b) { 
        this.bookings.remove(b); 
    }
}