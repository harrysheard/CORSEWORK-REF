package vetsystem;

public class Cat extends Pet {
    private static final long serialVersionUID = 1L;
    
    private String breeding;

    public Cat(String petRef, String name, Surgery initialSurgery, String breeding) {
        super(petRef, name, "Cat", initialSurgery);
        this.breeding = breeding;
    }

    public String getBreeding() { 
        return breeding; 
    }
}