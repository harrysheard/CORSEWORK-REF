package vetsystem;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Booking implements Serializable {
    private static final long serialVersionUID = 1L;

    private UUID bookingRef;
    private List<Staff> assignedStaff;
    private Pet pet;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    public Booking(Pet pet, LocalDateTime startTime, LocalDateTime endTime) {
        this.bookingRef = UUID.randomUUID();
        this.pet = pet;
        this.startTime = startTime;
        this.endTime = endTime;
        this.assignedStaff = new ArrayList<Staff>();
    }

    public UUID getBookingRef() { 
        return bookingRef; 
    }
    
    public List<Staff> getAssignedStaff() { 
        return assignedStaff; 
    }
    
    public Pet getPet() { 
        return pet; 
    }
    
    public LocalDateTime getStartTime() { 
        return startTime; 
    }
    
    public LocalDateTime getEndTime() { 
        return endTime; 
    }

    public void addStaff(Staff s) { 
        this.assignedStaff.add(s); 
    }
}