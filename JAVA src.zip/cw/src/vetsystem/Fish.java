package vetsystem;

public class Fish extends Pet {
    private static final long serialVersionUID = 1L;
    
    private String waterType;

    public Fish(String petRef, String name, Surgery initialSurgery, String waterType) {
        super(petRef, name, "Fish", initialSurgery);
        this.waterType = waterType;
    }

    public String getWaterType() { 
        return waterType; 
    }
}